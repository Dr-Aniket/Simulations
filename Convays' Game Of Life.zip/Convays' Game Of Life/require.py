import os

imports = ['pygame','colorama','pyfiglet']
for i in imports:
    os.system(f'pip install {i}')
    
print('Ho gaya saara')
import time
time.sleep(2)
